"use strict";
const $ = (id) => document.getElementById(id);
const eur = (n) => (n == null ? "—" : new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(n));

function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  Object.entries(props).forEach(([k, v]) => { if (k === "class") node.className = v; else node.setAttribute(k, v); });
  children.flat().forEach((c) => node.append(c));
  return node;
}

async function api(path, body) {
  const opts = { headers: { "X-Requested-With": "fretrau", "Content-Type": "application/json" }, credentials: "same-origin" };
  if (body !== undefined) { opts.method = "POST"; opts.body = JSON.stringify(body); }
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Erreur");
  return data;
}

$("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const err = $("login-error");
  err.classList.add("hidden");
  try {
    await api("/api/admin/login", { user: "admin", password: $("pw").value, totp: $("totp").value });
    $("pw").value = ""; $("totp").value = "";
    load();
  } catch (ex) { err.textContent = ex.message; err.classList.remove("hidden"); }
});

async function load() {
  const [stats, list] = await Promise.all([api("/api/admin/stats"), api("/api/admin/bookings")]);
  $("login").classList.add("hidden");
  $("dash").classList.remove("hidden");
  const tile = (label, value) => el("div", { class: "tile" }, el("b", {}, String(value)), label);
  $("tiles").replaceChildren(
    tile("Réservations", stats.bookings), tile("Confirmées", stats.confirmed), tile("À traiter (humain)", stats.pending_human),
    tile("Chiffre d'affaires HT", eur(stats.revenue_ht)), tile("Marge brute HT", eur(stats.margin_ht)),
    tile("Intégrité du journal", stats.audit_intact ? "Intacte" : "ALTÉRÉE"));
  const mails = await api("/api/admin/outbox");
  $("outbox").replaceChildren(...mails.mails.map((m) =>
    el("tr", {}, el("td", {}, new Date(m.created_at * 1000).toLocaleString("fr-FR")), el("td", {}, m.to_addr), el("td", {}, m.subject), el("td", {}, m.status))));
  $("rows").replaceChildren(...list.bookings.map((b) => {
    const tr = el("tr", { class: "click" },
      el("td", {}, String(b.id)), el("td", {}, b.tracking_code), el("td", {}, b.route),
      el("td", {}, el("span", { class: "pill " + b.status }, b.status === "confirmed" ? "Confirmée" : "À traiter")),
      el("td", {}, b.carrier_name || "—"), el("td", {}, eur(b.customer_price_ht)), el("td", {}, eur(b.carrier_price)));
    tr.addEventListener("click", () => detail(b.id));
    return tr;
  }));
  $("audit").replaceChildren(...stats.audit.map((a) =>
    el("tr", {}, el("td", {}, new Date(a.ts * 1000).toLocaleString("fr-FR")), el("td", {}, a.actor), el("td", {}, a.action), el("td", {}, a.detail || ""))));
}

async function detail(id) {
  const b = await api("/api/admin/booking/" + id);
  const log = b.agent_log;
  const box = $("detail");
  box.classList.remove("hidden");
  box.replaceChildren(
    el("h2", {}, `Réservation ${b.tracking_code}`),
    el("p", {}, `${b.customer.name} (${b.customer.company}) — ${b.customer.email} — ${b.customer.phone}`),
    el("h3", {}, "Agent de conformité — transporteurs écartés"),
    ...(log.rejected_by_compliance.length ? log.rejected_by_compliance.map((r) => el("p", {}, `${r.carrier} : ${r.reasons.join(" ; ")}`)) : [el("p", { class: "muted" }, "Aucun.")]),
    el("h3", {}, "Agent de comparaison — classement"),
    ...log.ranking.map((r, i) => el("p", {}, `${i + 1}. ${r.carrier} — score ${r.score} — ${r.why}`)),
    el("h3", {}, "Agent de négociation"),
    ...log.negotiations.flatMap((n) => [
      el("p", {}, el("b", {}, n.carrier), ` — ${n.accepted ? `accord à ${eur(n.price)} (marge ${eur(n.margin_eur)}, ${n.margin_pct} %)` : "pas d'accord, escalade humaine"} — plafond ${eur(n.ceiling)}`),
      ...n.transcript.map((m) => el("div", { class: "chat" }, el("div", { class: m.role }, `${m.role} : ${m.text}`))),
    ]),
  );
  if (b.status === "confirmed") {
    const btn = el("button", { class: "ghost" }, "Générer la facture");
    btn.addEventListener("click", () => invoice(b.id, box));
    box.append(btn);
  }
  box.scrollIntoView({ behavior: "smooth" });
}

async function invoice(id, box) {
  const f = await api("/api/admin/invoice/" + id);
  const old = document.getElementById("invoice-view");
  if (old) old.remove();
  const s = f.seller;
  box.append(el("div", { id: "invoice-view", class: "card" },
    el("h3", {}, `Facture ${f.number} du ${f.issued_on}`),
    el("p", {}, `${s.name} — ${s.legal_form} — ${s.address} — SIRET ${s.siret} — TVA ${s.vat_number}`),
    el("p", {}, `Client : ${f.buyer.name} (${f.buyer.company})`),
    el("p", {}, f.line),
    el("p", {}, `Total HT ${eur(f.total_ht)} — TVA ${(f.vat_rate * 100).toFixed(0)} % ${eur(f.vat)} — Total TTC ${eur(f.total_ttc)}`),
    f.vat_note ? el("p", { class: "muted" }, f.vat_note) : "",
    el("p", {}, `Échéance : ${f.due_on}`),
    ...f.legal.map((t) => el("p", { class: "muted" }, t))));
}

load().catch(() => {});   // session déjà valide ? sinon on reste sur le formulaire de connexion
