#!/usr/bin/env python3
"""Serveur FRETRAU (bibliothèque standard uniquement, aucune dépendance).

Lancement :  FRETRAU_ADMIN_PASSWORD='un-mot-de-passe-long' python3 server.py
Variables :  PORT, HOST, FRETRAU_DB, FRETRAU_SECRET, FRETRAU_HTTPS=1, FRETRAU_TRUST_PROXY=1,
             FRETRAU_DEMO_SPEED (1 = temps réel, 360 = 1 h simulée en 10 s), ANTHROPIC_API_KEY (optionnel)
"""
import html
import json
import os
import re
import secrets
import time
from dataclasses import asdict
from datetime import date, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from fretrau import booking, geo, invoicing, mailer, pricing, security
from fretrau.agents import email_agent, llm
from fretrau.db import DB

ROOT = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(ROOT, "web")
MIME = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
        ".js": "application/javascript; charset=utf-8", ".svg": "image/svg+xml", ".txt": "text/plain; charset=utf-8", ".ico": "image/x-icon"}

HTTPS = os.environ.get("FRETRAU_HTTPS") == "1"
TRUST_PROXY = os.environ.get("FRETRAU_TRUST_PROXY") == "1"
DEMO_SPEED = float(os.environ.get("FRETRAU_DEMO_SPEED", "1"))

_admin_pw = os.environ.get("FRETRAU_ADMIN_PASSWORD")
if not _admin_pw:
    _admin_pw = secrets.token_urlsafe(16)
    print(f"[FRETRAU] Aucun FRETRAU_ADMIN_PASSWORD défini. Mot de passe admin temporaire : {_admin_pw}")
if len(_admin_pw) < 12:
    raise SystemExit("[FRETRAU] FRETRAU_ADMIN_PASSWORD doit contenir au moins 12 caractères.")
ADMIN_HASH = security.hash_password(_admin_pw)
del _admin_pw
TOTP_SECRET = os.environ.get("FRETRAU_ADMIN_TOTP_SECRET")          # 2FA admin (recommandé)
WEBHOOK_SECRET = os.environ.get("FRETRAU_WEBHOOK_SECRET", "")       # signe les e-mails entrants
PUBLIC_URL = os.environ.get("FRETRAU_PUBLIC_URL", "http://127.0.0.1:8080")
if not TOTP_SECRET:
    print("[FRETRAU] ATTENTION : 2FA admin désactivée. Générez un secret : "
          "python3 -c \"from fretrau.security import new_totp_secret as n; print(n())\" "
          "puis FRETRAU_ADMIN_TOTP_SECRET=... (à ajouter dans une application d'authentification).")
SESSIONS = security.Sessions(os.environ.get("FRETRAU_SECRET", secrets.token_hex(32)).encode())

DB_ = DB(os.environ.get("FRETRAU_DB", os.path.join(ROOT, "fretrau.db")))
RL_GLOBAL = security.RateLimiter(120, 60)
RL_QUOTE = security.RateLimiter(20, 60)
RL_BOOK = security.RateLimiter(5, 600)
RL_LOGIN = security.RateLimiter(10, 900)
RL_TRACK = security.RateLimiter(30, 60)
GUARD = security.LoginGuard()


class ApiError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message


class Handler(BaseHTTPRequestHandler):
    server_version = "FRETRAU"
    sys_version = ""

    # ---------- utilitaires ----------
    def log_message(self, fmt, *args):          # pas de corps de requête dans les logs
        pass

    def ip(self):
        if TRUST_PROXY and self.headers.get("X-Forwarded-For"):
            return self.headers["X-Forwarded-For"].split(",")[0].strip()
        return self.client_address[0]

    def _headers(self, status, ctype, length, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        for k, v in security.SECURITY_HEADERS.items():
            self.send_header(k, v)
        if HTTPS:
            self.send_header("Strict-Transport-Security", security.HSTS)
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()

    def send_json(self, status, obj, extra=None):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self._headers(status, "application/json; charset=utf-8", len(body), extra)
        self.wfile.write(body)

    def send_bytes(self, status, ctype, body, extra=None):
        self._headers(status, ctype, len(body), extra)
        self.wfile.write(body)

    def read_json(self, raw_out=None):
        if not (self.headers.get("Content-Type") or "").startswith("application/json"):
            raise ApiError(415, "Content-Type application/json requis.")
        try:
            n = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(400, "Requête invalide.")
        if n <= 0 or n > security.MAX_BODY:
            raise ApiError(413, "Corps de requête invalide ou trop volumineux.")
        try:
            raw = self.rfile.read(n)
            if raw_out is not None:
                raw_out.append(raw)
            data = json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ApiError(400, "JSON invalide.")
        if not isinstance(data, dict):
            raise ApiError(400, "Objet JSON attendu.")
        return data

    def admin_user(self):
        if self.headers.get("X-Requested-With") != "fretrau":
            return None
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == "fretrau_admin":
                return SESSIONS.verify(v)
        return None

    def require_admin(self):
        user = self.admin_user()
        if not user:
            raise ApiError(401, "Authentification requise.")
        return user

    # ---------- routage ----------
    def dispatch(self, method):
        try:
            if not RL_GLOBAL.allow(self.ip()):
                raise ApiError(429, "Trop de requêtes, réessayez dans une minute.")
            path = urlparse(self.path).path
            origin = self.headers.get("Origin")
            if method == "POST" and origin and urlparse(origin).netloc != self.headers.get("Host"):
                raise ApiError(403, "Origine non autorisée.")
            if path.startswith("/api/"):
                return self.api(method, path)
            if method != "GET":
                raise ApiError(405, "Méthode non autorisée.")
            return self.static(path)
        except ApiError as e:
            self.send_json(e.status, {"error": e.message})
        except Exception:
            self.send_json(500, {"error": "Erreur interne."})      # jamais de trace au client

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    # ---------- fichiers statiques ----------
    def static(self, path):
        if path in ("/", ""):
            path = "/index.html"
        full = os.path.realpath(os.path.join(WEB, path.lstrip("/")))
        ext = os.path.splitext(full)[1].lower()
        if not full.startswith(WEB + os.sep) or ext not in MIME or not os.path.isfile(full):
            raise ApiError(404, "Introuvable.")
        with open(full, "rb") as f:
            self.send_bytes(200, MIME[ext], f.read())

    # ---------- API ----------
    def api(self, method, path):
        if method == "GET" and path == "/api/cities":
            return self.send_json(200, {"cities": sorted(geo.CITIES), "options": pricing.OPTIONS,
                                        "llm": llm.available()})
        if method == "POST" and path == "/api/quote":
            return self.api_quote()
        if method == "POST" and path == "/api/book":
            return self.api_book()
        m = re.fullmatch(r"/api/track/([^/]+)", path)
        if method == "GET" and m:
            return self.api_track(m.group(1))
        m = re.fullmatch(r"/api/doc/([^/]+)", path)
        if method == "GET" and m:
            return self.api_doc(m.group(1))
        if method == "POST" and path == "/api/webhook/inbound-mail":
            return self.api_inbound_mail()
        if path.startswith("/api/admin/"):
            return self.api_admin(method, path)
        raise ApiError(404, "Introuvable.")

    def api_quote(self):
        if not RL_QUOTE.allow(self.ip()):
            raise ApiError(429, "Trop de devis demandés, patientez un instant.")
        d = self.read_json()
        try:
            origin = security.clean_text(d.get("origin"), 60)
            destination = security.clean_text(d.get("destination"), 60)
            mode = security.clean_text(d.get("mode"), 3)
            pallets = d.get("pallets")
            weight = d.get("weight_kg")
            if isinstance(pallets, bool) or isinstance(weight, bool):
                raise ValueError("Valeur numérique invalide.")
            options = d.get("options") if isinstance(d.get("options"), dict) else {}
            q = pricing.build_quote(origin, destination, mode, pallets, weight, options)
            pickup = date.fromisoformat(security.clean_text(d.get("pickup_date"), 10))
        except pricing.QuoteError as e:
            raise ApiError(422, str(e))
        except ValueError:
            raise ApiError(422, "Données invalides : vérifiez le formulaire.")
        today = date.today()
        if not today <= pickup <= today + timedelta(days=60):
            raise ApiError(422, "La date d'enlèvement doit être dans les 60 prochains jours.")

        quote_id = secrets.token_urlsafe(12)
        shipment = {"pallets": pallets, "weight_kg": weight, "pickup_date": pickup.isoformat(),
                    "options": {k: bool(v) for k, v in options.items() if k in pricing.OPTIONS}}
        DB_.save_quote(quote_id, {"quote": asdict(q), "shipment": shipment})
        scale = q.price_ht / q.carrier_cost_estimate        # le détail client inclut la marge, pas le coût brut
        lines = {k: round(v * scale, 2) for k, v in q.breakdown.items()}
        self.send_json(200, {
            "quote_id": quote_id, "price_ht": q.price_ht, "vat": q.vat, "price_ttc": q.price_ttc,
            "distance_km": q.distance_km, "transit_days": q.transit_days, "breakdown": lines,
            "valid_hours": 24, "mode": q.mode,
        })

    def api_book(self):
        if not RL_BOOK.allow(self.ip()):
            raise ApiError(429, "Trop de réservations, patientez avant de réessayer.")
        d = self.read_json()
        if d.get("website"):                                  # champ piège anti-robots (honeypot)
            return self.send_json(200, {"ok": True})
        if d.get("accept_cgv") is not True:
            raise ApiError(422, "Vous devez accepter les conditions générales.")
        stored = DB_.get_quote(str(d.get("quote_id", ""))[:40])
        if not stored:
            raise ApiError(404, "Devis introuvable ou expiré.")
        quote_id = d["quote_id"]
        if DB_.booking_exists_for_quote(quote_id):
            raise ApiError(409, "Ce devis a déjà été réservé.")
        c = d.get("contact") if isinstance(d.get("contact"), dict) else {}
        try:
            customer = {
                "name": security.clean_text(c.get("name"), 80),
                "company": security.clean_text(c.get("company"), 120),
                "email": security.clean_text(c.get("email"), 254),
                "phone": security.clean_text(c.get("phone"), 20),
            }
            if not security.EMAIL_RE.match(customer["email"]) or not security.PHONE_RE.match(customer["phone"]):
                raise ValueError("Coordonnées invalides.")
            shipment = dict(stored["shipment"])
            shipment.update({
                "origin": stored["quote"]["origin"], "destination": stored["quote"]["destination"],
                "mode": stored["quote"]["mode"],
                "pickup_address": security.clean_text(d.get("pickup_address"), 200),
                "delivery_address": security.clean_text(d.get("delivery_address"), 200),
                "goods": security.clean_text(d.get("goods"), 200),
            })
        except ValueError as e:
            raise ApiError(422, str(e))

        result = booking.run(stored["quote"], date.fromisoformat(shipment["pickup_date"]))
        code = booking.new_tracking_code()
        carrier = result["carrier"]
        DB_.save_booking(
            tracking_code=code, quote_id=quote_id, status=result["status"], customer=customer,
            shipment=shipment, carrier_id=carrier.id if carrier else None,
            carrier_name=carrier.name if carrier else None, carrier_price=result["price"],
            customer_price_ht=stored["quote"]["price_ht"], agent_log=result["log"])
        DB_.audit("system", "booking_created", f"{code} status={result['status']}")
        subject, body = (mailer.booking_confirmation(customer, code, shipment, stored["quote"]["price_ht"], PUBLIC_URL)
                         if result["status"] == "confirmed" else mailer.booking_pending(customer, code, PUBLIC_URL))
        try:
            mailer.queue(DB_, customer["email"], subject, body)
            mailer.flush(DB_)
        except Exception:
            pass                                              # un e-mail en échec ne bloque jamais la réservation
        self.send_json(201, {"tracking_code": code, "status": result["status"]})

    def _public_booking(self, code):
        if not RL_TRACK.allow(self.ip()):
            raise ApiError(429, "Trop de requêtes.")
        if not security.CODE_RE.match(code):
            raise ApiError(404, "Code de suivi inconnu.")
        b = DB_.booking_by_code(code)
        if not b:
            raise ApiError(404, "Code de suivi inconnu.")
        return b

    def api_track(self, code):
        b = self._public_booking(code)
        shipment = json.loads(b["shipment"])
        events = booking.timeline(b["created_at"], time.time(), DEMO_SPEED) if b["status"] == "confirmed" else []
        self.send_json(200, {
            "tracking_code": code, "status": b["status"], "origin": shipment["origin"],
            "destination": shipment["destination"], "events": events,
            "message": None if b["status"] == "confirmed" else
            "Votre demande est en cours de traitement par notre équipe, vous serez contacté rapidement.",
        })

    def api_doc(self, code):
        b = self._public_booking(code)
        if b["status"] != "confirmed":
            raise ApiError(409, "Document disponible après confirmation du transport.")
        s, cu = json.loads(b["shipment"]), json.loads(b["customer"])
        e = lambda v: html.escape(str(v))                       # noqa: E731 — échappement XSS
        rows = [("Expéditeur", f"{cu['name']} — {cu['company']}"), ("Lieu d'enlèvement", s["pickup_address"]),
                ("Lieu de livraison", s["delivery_address"]), ("Marchandise", s["goods"]),
                ("Palettes", s.get("pallets")), ("Poids (kg)", s["weight_kg"]),
                ("Date d'enlèvement", s["pickup_date"]), ("Transporteur", b["carrier_name"])]
        body = "".join(f"<tr><th>{e(k)}</th><td>{e(v)}</td></tr>" for k, v in rows)
        page = (f"<!doctype html><html lang='fr'><head><meta charset='utf-8'><title>Lettre de voiture {e(code)}</title>"
                f"<link rel='stylesheet' href='/styles.css'></head><body class='doc'><h1>Lettre de voiture</h1>"
                f"<p class='muted'>N° {e(code)} — document de démonstration, à remplacer par un modèle CMR "
                f"conforme avant tout usage réel.</p><table class='doc-table'>{body}</table></body></html>")
        self.send_bytes(200, "text/html; charset=utf-8", page.encode())

    def api_inbound_mail(self):
        """Réponse e-mail d'un transporteur (relayée par votre service de messagerie). Signature HMAC obligatoire."""
        if not WEBHOOK_SECRET:
            raise ApiError(503, "Webhook non configuré.")
        raw = []
        d = self.read_json(raw)
        import hashlib, hmac
        expected = hmac.new(WEBHOOK_SECRET.encode(), raw[0], hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, self.headers.get("X-Signature", "")):
            DB_.audit("anonymous", "webhook_bad_signature", self.ip())
            raise ApiError(401, "Signature invalide.")
        ts = d.get("ts")
        if not isinstance(ts, (int, float)) or abs(time.time() - ts) > 300:          # anti-rejeu
            raise ApiError(400, "Horodatage invalide ou expiré.")
        code, carrier_id, text = d.get("tracking_code"), d.get("carrier_id"), d.get("text")
        if (not isinstance(code, str) or not security.CODE_RE.match(code) or isinstance(carrier_id, bool)
                or not isinstance(carrier_id, int) or not isinstance(text, str) or len(text) > 5000):
            raise ApiError(422, "Données invalides.")
        result = email_agent.handle(DB_, code, carrier_id, text)
        DB_.audit("email_agent", "inbound_" + result["decision"], f"{code} carrier={carrier_id}")
        if result["decision"] == "accepted":
            b = DB_.booking_by_code(code)
            cu, sh = json.loads(b["customer"]), json.loads(b["shipment"])
            try:
                subject, body = mailer.booking_confirmation(cu, code, sh, b["customer_price_ht"], PUBLIC_URL)
                mailer.queue(DB_, cu["email"], subject, body)
                mailer.flush(DB_)
            except Exception:
                pass
        self.send_json(200, result)

    # ---------- admin ----------
    def api_admin(self, method, path):
        if method == "POST" and path == "/api/admin/login":
            ip = self.ip()
            if not RL_LOGIN.allow(ip) or GUARD.locked(ip):
                raise ApiError(429, "Trop de tentatives. Réessayez plus tard.")
            d = self.read_json()
            ok = (d.get("user") == "admin" and isinstance(d.get("password"), str)
                  and security.verify_password(d["password"], ADMIN_HASH))
            if ok and TOTP_SECRET and not security.verify_totp(TOTP_SECRET, str(d.get("totp", ""))):
                ok = False
            if not ok:
                GUARD.fail(ip)
                DB_.audit("anonymous", "admin_login_failed", ip)
                raise ApiError(401, "Identifiants invalides.")
            GUARD.ok(ip)
            DB_.audit("admin", "admin_login", ip)
            cookie = (f"fretrau_admin={SESSIONS.issue('admin')}; HttpOnly; SameSite=Strict; Path=/; Max-Age=3600"
                      + ("; Secure" if HTTPS else ""))
            return self.send_json(200, {"ok": True}, {"Set-Cookie": cookie})
        self.require_admin()
        if method == "GET" and path == "/api/admin/bookings":
            rows = DB_.list_bookings()
            for r in rows:
                s = json.loads(r.pop("shipment"))
                r["route"] = f"{s['origin']} → {s['destination']}"
            return self.send_json(200, {"bookings": rows})
        m = re.fullmatch(r"/api/admin/booking/(\d{1,9})", path)
        if method == "GET" and m:
            b = DB_.booking_by_id(int(m.group(1)))
            if not b:
                raise ApiError(404, "Introuvable.")
            for k in ("customer", "shipment", "agent_log"):
                b[k] = json.loads(b[k])
            DB_.audit("admin", "view_booking", str(b["id"]))
            return self.send_json(200, b)
        m = re.fullmatch(r"/api/admin/invoice/(\d{1,9})", path)
        if method == "GET" and m:
            b = DB_.booking_by_id(int(m.group(1)))
            if not b or b["status"] != "confirmed":
                raise ApiError(404, "Facture indisponible (transport non confirmé).")
            inv = DB_.get_or_create_invoice(b["id"], invoicing.build(b))
            DB_.audit("admin", "invoice", inv["number"])
            return self.send_json(200, inv)
        if method == "GET" and path == "/api/admin/outbox":
            return self.send_json(200, {"mails": DB_.list_outbox()})
        if method == "POST" and path == "/api/admin/gdpr/anonymize":
            code = str(self.read_json().get("tracking_code", ""))
            if not security.CODE_RE.match(code) or not DB_.anonymize_booking(code):
                raise ApiError(404, "Réservation introuvable.")
            DB_.audit("admin", "gdpr_anonymize", code)
            return self.send_json(200, {"ok": True})
        if method == "GET" and path == "/api/admin/stats":
            rows = DB_.list_bookings(10000)
            done = [r for r in rows if r["status"] == "confirmed"]
            revenue = sum(r["customer_price_ht"] for r in done)
            cost = sum(r["carrier_price"] or 0 for r in done)
            return self.send_json(200, {
                "bookings": len(rows), "confirmed": len(done),
                "pending_human": len(rows) - len(done),
                "revenue_ht": round(revenue, 2), "margin_ht": round(revenue - cost, 2),
                "audit": DB_.audit_tail(20), "audit_intact": DB_.verify_audit_chain()[0]})
        raise ApiError(404, "Introuvable.")


def make_server(host="127.0.0.1", port=8080):
    return ThreadingHTTPServer((host, port), Handler)


if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8080"))
    print(f"[FRETRAU] http://{host}:{port}  (admin : /admin.html)  LLM: {'actif' if llm.available() else 'gabarits'}")
    make_server(host, port).serve_forever()
