"""Orchestrateur de réservation : conformité → comparaison → négociation → affectation."""
import secrets
from datetime import date

from . import pricing
from .agents import sourcing, negotiation
from .carriers import CARRIERS

MAX_CARRIERS_TRIED = 3
# Jalons de suivi (heures après la réservation) — démonstration ; en production : API télématique.
TIMELINE = [
    (0, "Commande confirmée"),
    (2, "Transporteur affecté"),
    (8, "Chargement effectué"),
    (14, "En transit"),
    (30, "Arrivée à destination"),
    (32, "Livré — preuve de livraison disponible"),
]


def quote_from_payload(p) -> pricing.Quote:
    return pricing.Quote(**p)


def run(quote_payload: dict, pickup: date) -> dict:
    quote = quote_from_payload(quote_payload)
    ranked, rejected = sourcing.rank(quote, pickup)
    log = {"rejected_by_compliance": rejected, "ranking": ranked, "negotiations": []}
    by_id = {c.id: c for c in CARRIERS}

    for cand in ranked[:MAX_CARRIERS_TRIED]:
        carrier = by_id[cand["carrier_id"]]
        result = negotiation.negotiate(quote, cand, carrier)
        log["negotiations"].append({"carrier": carrier.name, **result})
        if result["accepted"]:
            return {"status": "confirmed", "carrier": carrier, "price": result["price"], "log": log}
    return {"status": "pending_human", "carrier": None, "price": None, "log": log}


def new_tracking_code() -> str:
    # 12 caractères aléatoires non devinables (évite l'énumération des expéditions).
    return "FR-" + secrets.token_hex(6).upper()


def timeline(created_at: float, now: float, speed: float = 1.0) -> list:
    """Événements déjà survenus. speed > 1 accélère la démo (ex. 360 : 1 h = 10 s)."""
    elapsed_h = (now - created_at) / 3600.0 * speed
    return [{"label": label, "offset_h": h, "done": elapsed_h >= h} for h, label in TIMELINE]
