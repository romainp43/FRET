"""Géographie : base de villes et distance routière estimée.

Approximation : distance à vol d'oiseau (haversine) x coefficient routier.
En production, remplacer par un service d'itinéraire (OSRM auto-hébergé, HERE, Google Routes).
"""
import math

# nom: (pays, latitude, longitude)
CITIES = {
    "Paris": ("FR", 48.8566, 2.3522),
    "Lyon": ("FR", 45.7640, 4.8357),
    "Marseille": ("FR", 43.2965, 5.3698),
    "Toulouse": ("FR", 43.6047, 1.4442),
    "Bordeaux": ("FR", 44.8378, -0.5792),
    "Nantes": ("FR", 47.2184, -1.5536),
    "Lille": ("FR", 50.6292, 3.0573),
    "Strasbourg": ("FR", 48.5734, 7.7521),
    "Rennes": ("FR", 48.1173, -1.6778),
    "Montpellier": ("FR", 43.6108, 3.8767),
    "Nice": ("FR", 43.7102, 7.2620),
    "Grenoble": ("FR", 45.1885, 5.7245),
    "Dijon": ("FR", 47.3220, 5.0415),
    "Clermont-Ferrand": ("FR", 45.7772, 3.0870),
    "Saint-Etienne": ("FR", 45.4397, 4.3872),
    "Le Puy-en-Velay": ("FR", 45.0430, 3.8850),
    "Rouen": ("FR", 49.4432, 1.0993),
    "Le Havre": ("FR", 49.4944, 0.1079),
    "Metz": ("FR", 49.1193, 6.1757),
    "Orléans": ("FR", 47.9029, 1.9093),
    "Madrid": ("ES", 40.4168, -3.7038),
    "Barcelone": ("ES", 41.3874, 2.1686),
    "Valence": ("ES", 39.4699, -0.3763),
    "Lisbonne": ("PT", 38.7223, -9.1393),
    "Milan": ("IT", 45.4642, 9.1900),
    "Turin": ("IT", 45.0703, 7.6869),
    "Rome": ("IT", 41.9028, 12.4964),
    "Bruxelles": ("BE", 50.8503, 4.3517),
    "Anvers": ("BE", 51.2194, 4.4025),
    "Amsterdam": ("NL", 52.3676, 4.9041),
    "Rotterdam": ("NL", 51.9244, 4.4777),
    "Francfort": ("DE", 50.1109, 8.6821),
    "Munich": ("DE", 48.1351, 11.5820),
    "Hambourg": ("DE", 53.5511, 9.9937),
    "Cologne": ("DE", 50.9375, 6.9603),
    "Stuttgart": ("DE", 48.7758, 9.1829),
    "Zurich": ("CH", 47.3769, 8.5417),
    "Genève": ("CH", 46.2044, 6.1432),
    "Luxembourg": ("LU", 49.6116, 6.1319),
    "Varsovie": ("PL", 52.2297, 21.0122),
    "Vienne": ("AT", 48.2082, 16.3738),
}


def known(city: str) -> bool:
    return city in CITIES


def country(city: str) -> str:
    return CITIES[city][0]


def haversine_km(a: str, b: str) -> float:
    _, la1, lo1 = CITIES[a]
    _, la2, lo2 = CITIES[b]
    r = 6371.0
    p1, p2 = math.radians(la1), math.radians(la2)
    dphi = p2 - p1
    dl = math.radians(lo2 - lo1)
    h = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def road_km(a: str, b: str) -> float:
    """Distance routière estimée (coefficient 1,20 national, 1,25 international)."""
    if a == b:
        return 0.0
    coef = 1.20 if country(a) == country(b) else 1.25
    return round(haversine_km(a, b) * coef, 1)


def transit_days(km: float, urgent: bool = False) -> int:
    """Délai estimé : ~600 km/jour de route, +1 jour de chargement/livraison."""
    days = math.ceil(km / 600.0) + (0 if urgent else 1)
    return max(1, days)
