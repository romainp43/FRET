"""Agent de négociation par e-mail : traite la réponse d'un transporteur pour une réservation « à traiter ».

Sécurité (anti-injection de prompt) : le texte reçu n'est jamais exécuté ni confié à un LLM qui déciderait.
On en extrait UN montant en euros (security.parse_amount), validé par du code, puis on compare au plafond
d'achat qui garantit la marge minimale. Le transporteur est re-contrôlé par l'agent de conformité.
"""
import json
from datetime import date

from .. import pricing, security
from ..carriers import CARRIERS
from . import compliance

COUNTER_TOLERANCE = 1.10      # jusqu'à +10 % au-dessus du plafond : contre-proposition au plafond


def handle(db, code: str, carrier_id: int, text: str) -> dict:
    b = db.booking_by_code(code)
    if not b:
        return {"decision": "rejected", "reason": "Réservation inconnue."}
    if b["status"] != "pending_human":
        return {"decision": "rejected", "reason": "Réservation non éligible (déjà traitée)."}

    carrier = {c.id: c for c in CARRIERS}.get(carrier_id)
    if not carrier:
        return {"decision": "rejected", "reason": "Transporteur inconnu."}
    shipment = json.loads(b["shipment"])
    ok, reasons = compliance.check(carrier, shipment["mode"], shipment["origin"], shipment["destination"],
                                   date.fromisoformat(shipment["pickup_date"]))
    if not ok:
        db.add_inbound(b["id"], carrier_id, text, None, "rejected_compliance")
        return {"decision": "rejected", "reason": "Non conforme : " + " ; ".join(reasons)}

    ceiling = round(b["customer_price_ht"] / (1 + pricing.MIN_MARGIN), 2)
    amount = security.parse_amount(text)
    if amount is None:
        db.add_inbound(b["id"], carrier_id, text, None, "escalate_no_amount")
        return {"decision": "escalate", "reason": "Montant absent, ambigu ou hors plage : traitement humain."}
    if amount <= ceiling:
        log = json.loads(b["agent_log"])
        log.setdefault("inbound", []).append({"carrier": carrier.name, "amount": amount, "ceiling": ceiling})
        db.assign_carrier(code, carrier.id, carrier.name, amount, log)
        db.add_inbound(b["id"], carrier_id, text, amount, "accepted")
        return {"decision": "accepted", "price": amount, "ceiling": ceiling}
    if amount <= ceiling * COUNTER_TOLERANCE:
        db.add_inbound(b["id"], carrier_id, text, amount, "counter")
        return {"decision": "counter", "amount": amount, "counter_price": ceiling}
    db.add_inbound(b["id"], carrier_id, text, amount, "escalate_too_high")
    return {"decision": "escalate", "reason": "Prix trop élevé pour la marge minimale.", "amount": amount}
